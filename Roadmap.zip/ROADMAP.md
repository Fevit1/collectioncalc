# CollectionCalc Roadmap

## Vision

**CollectionCalc is a multi-collectible valuation platform.** 

Comics are the first vertical. Future expansion includes:
- Sports cards (baseball, basketball, football, hockey)
- Trading card games (Pokémon, Magic: The Gathering, Yu-Gi-Oh!)
- Coins & numismatics
- Stamps
- Vinyl records
- Video games
- Sneakers
- Watches

Our goal: Build the most accurate, user-informed valuation tool by combining real market data with community feedback - across ALL collectibles.

**Strategic Exit:** Become acquisition target for eBay or Amazon by owning the most comprehensive real-time pricing intelligence across collectibles markets.

---

## Completed ✅

### Phase 0: Core MVP
- [x] Database schema (SQLite → PostgreSQL)
- [x] Basic valuation model with grade adjustments
- [x] Comic lookup system
- [x] API server (Flask)
- [x] Deployed to Render
- [x] Basic frontend UI

### Phase 1: Infrastructure
- [x] GitHub repo setup
- [x] CORS support for frontend
- [x] Health check endpoints
- [x] Error handling
- [x] Frontend hosted on Cloudflare Pages
- [x] Backend hosted on Render

### Phase 2: eBay-Powered Valuation Model ✅
Real market data with intelligent weighting.

- [x] AI web search for market prices (eBay, GoCollect, etc.)
- [x] Parse recent sale prices with dates and grades
- [x] Recency weighting (this week 100% → older 25%)
- [x] Volume-based confidence scoring
- [x] Price variance analysis
- [x] Database + market data blending
- [x] 48-hour result caching for consistency
- [x] Title alias table (ASM → Amazing Spider-Man)
- [x] AI spelling correction ("Captian" → "Captain")

### Phase 2.5: Brand & UX ✅
- [x] Brand guidelines document (Option 3: Dark + Gradient)
- [x] New color scheme (Indigo/Purple/Cyan)
- [x] Animated calculator loading icon
- [x] Thinking steps display
- [x] Price formatting with commas

### Phase 2.7: Three-Tier Pricing ✅
Actionable pricing for different selling scenarios.

- [x] Three-tier valuation display:
  - **Quick Sale** - Lowest BIN or floor price (sell fast)
  - **Fair Value** - Median sold price (market value)
  - **High End** - Maximum recent sold (premium/patient seller)
- [x] Buy It Now price integration (current market ceiling)
- [x] Tighter grade filtering (±0.5 grade tolerance)
- [x] Cache now stores all pricing tiers
- [x] PostgreSQL database migration (from SQLite)
- [x] Per-tier confidence scoring

### Phase 2.8: eBay Listing Integration ✅ (January 19, 2026)
**MILESTONE: First live eBay listing created from CollectionCalc!**

One-click listing from valuation results.

- [x] eBay Developer account registered
- [x] eBay Developer API approved
- [x] OAuth flow for user eBay accounts (Production)
- [x] "List on eBay" buttons (3 price tiers)
- [x] AI-generated descriptions (300 char limit for mobile)
- [x] Listing preview modal with editable description
- [x] Placeholder image support
- [x] Auto-find user's business policies (shipping, payment, returns)
- [x] Auto-create merchant location
- [x] Package weight/dimensions for calculated shipping
- [x] Condition mapping (grade → eBay condition enum)
- [x] Create eBay listing via Inventory API
- [x] Listing published to live eBay! 🎉

**Technical details:**
- Category ID: 259104 (Comics & Graphic Novels)
- Package: 1" x 11" x 7", 8 oz, LETTER type
- SKU: CC-{title}-{issue}-{timestamp}
- Condition: LIKE_NEW, USED_EXCELLENT, USED_VERY_GOOD, USED_GOOD, USED_ACCEPTABLE

### Phase 2.85: QuickList Batch Processing ✅ (January 20, 2026)
**Full pipeline from photo to eBay draft listing.**

- [x] Draft mode for eBay listings (`publish=False` by default)
- [x] Photo upload to eBay Picture Services
- [x] Backend extraction via Claude vision (`comic_extraction.py`)
- [x] Batch processing endpoints:
  - `/api/extract` - Extract single comic from photo
  - `/api/batch/process` - Extract + Valuate + Describe multiple comics
  - `/api/batch/list` - Upload images + Create drafts (after approval)
- [x] Input validation (max 20 comics, 10MB images)
- [x] Removed 60-second delay between valuations (was Tier 1 leftover)
- [x] UI: Three price boxes (Quick/Fair/High) with Fair Value default
- [x] UI: "List on eBay" button per comic in batch results
- [x] UI: Removed confidence row (details via 📊 icon)
- [x] UI: Removed regenerate button
- [x] UI: Sort options (Value High/Low, Title A-Z, Order Added)
- [x] UI: Header syncs when editing title/issue fields
- [x] Vision Guide v1: Improved extraction prompt (distinguishes issue numbers from prices)

**QuickList Flow:**
1. Upload → 2. Extract → 3. Review/Edit → 4. Valuate → 5. Describe → 6. List as Draft

### Phase 2.86: QuickList Polish ✅ (January 21, 2026)
Refine the batch experience.

- [x] Sort options (by value, title) in batch results ✅
- [x] Vision Guide v1 for extraction (price vs issue number) ✅
- [x] GDPR account deletion endpoint ✅
- [x] Smart image compression (client-side, files > 3.5MB) ✅
- [x] Image thumbnails in extraction view ✅
- [x] Image thumbnails in results view ✅
- [x] Image in listing preview modal ✅
- [x] Mobile extraction/valuation/listing working ✅
- [x] `purge` command for Cloudflare cache ✅
- [ ] More progress steps during valuation (keep users engaged)
- [ ] Custom price entry (not just the three tiers)

### Phase 2.88: User Auth & Collections ✅ (January 21, 2026)
**Users can create accounts and save their comics.**

- [x] Email/password authentication (signup, login, logout)
- [x] Email verification via Resend (collectioncalc.com domain)
- [x] Forgot password / password reset flow
- [x] JWT tokens (30-day expiry)
- [x] Database tables: users, collections, password_resets
- [x] Save comics to collection
- [x] View collection (basic)
- [x] Auth UI in header (login/signup buttons, user menu)
- [x] "Save to Collection" button in results view

**Technical details:**
- Auth backend: `auth.py` with bcrypt password hashing
- Email service: Resend (3k emails/mo free)
- Frontend: Modal-based login/signup forms
- Storage: PostgreSQL (same DB as valuations)

---

## In Progress 🔨

### Phase 2.87: Extraction Accuracy (Vision Guide v2)
Further improve AI's ability to read comic covers.

**Completed (v1):**
- [x] Distinguish prices (60¢, $1.50) from issue numbers (#242)
- [x] Look for "#" or "No." prefix for issue numbers
- [x] Focus on TOP-LEFT area for issue numbers

**Completed (v2 - Session 7):**
- [x] Multi-location issue search (top-left, top-right, near barcode, near title)
- [x] DC comics support (issue # often top-right)
- [x] Signature detection with confidence analysis
- [x] Signature analysis UI (green box with creator confidence %)
- [x] Auto-populate "Signed copy" checkbox from AI detection
- [x] Frontend split into 3 files (index.html, styles.css, app.js)
- [x] Improved image quality processing (upscale small images to 1200px)

**In Progress:**
- [ ] EXIF auto-rotation (code deployed, needs debugging)
- [ ] Manual rotate button (↻) (code deployed, needs debugging)

**Pending (v2):**
- [ ] Ignore: price stickers, store stamps, grade labels, bag reflections
- [ ] Multiple numbers context: price vs issue vs volume vs year
- [ ] Common OCR confusions (#1 vs #7, etc.)

**Known Limitation:** Signature detection requires high-quality images (~3000px). Facebook/Messenger-compressed images (~500px) are too degraded. Tell testers to EMAIL original photos.

### Phase 2.89: Frontend Code Refactor ✅ (January 22, 2026)
Split monolithic index.html for maintainability.

- [x] Split into 3 files:
  - `index.html` (~310 lines) - HTML structure only
  - `styles.css` (~1350 lines) - All CSS
  - `app.js` (~2030 lines) - All JavaScript
- [x] Same deployment process (git push; purge)
- [x] Fixes file truncation issues during editing

---

## Phase 3: Unified FMV Engine 🧠 (NEW)

**The FMV Engine is the core intelligence layer that combines multiple data sources into accurate, confidence-weighted valuations.**

This architecture is inspired by marketing mix models and autonomous intelligence systems - the same principles that drive dynamic pricing in hotels, airlines, and advertising platforms.

### Phase 3.1: Multi-Source Data Integration (Current Focus)

**Data Sources:**
| Source | Type | Unique Value | Status |
|--------|------|--------------|--------|
| eBay Completed | Auction + BIN | Highest volume | ✅ Live |
| eBay Active BIN | Current listings | Price ceiling | ✅ Live |
| Whatnot Live | Live auction | True price discovery | 🔨 Integrating |
| PriceCharting | Aggregated | Historical trends | 📋 Planned |
| GoCollect | CGC census | Population data | 📋 Planned |

**Whatnot Valuator Chrome Extension:**
- Companion tool that captures live auction sales from Whatnot.com
- Vision-powered comic identification (reads slabs, identifies grades)
- Currently stores to Supabase (539 sales captured)
- **Migration:** Moving to CollectionCalc PostgreSQL for unified data

**Unified Schema:**
```sql
CREATE TABLE market_sales (
    id SERIAL PRIMARY KEY,
    source TEXT NOT NULL,           -- 'whatnot', 'ebay', 'pricecharting'
    
    -- Core comic identity
    title TEXT,
    series TEXT,
    issue INTEGER,
    grade NUMERIC,
    grade_source TEXT,              -- 'cgc', 'cbcs', 'raw', 'vision'
    slab_type TEXT,
    variant TEXT,
    is_key BOOLEAN DEFAULT FALSE,
    
    -- Sale data
    price NUMERIC NOT NULL,
    sold_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    
    -- Source-specific context
    raw_title TEXT,
    seller TEXT,
    bids INTEGER,                   -- Whatnot/eBay auction
    viewers INTEGER,                -- Whatnot specific
    image_url TEXT,
    source_id TEXT,                 -- External ID for deduplication
    
    UNIQUE(source, source_id)
);
```

**New API Endpoints:**
- `POST /api/sales/record` - Whatnot extension writes sales here
- `GET /api/fmv?title=X&issue=Y&grade=Z` - Unified FMV from all sources

### Phase 3.2: Intelligent Weighting Model

**Recency Decay (Aggressive):**
```
Last 24 hours:  1.0
Last 7 days:    0.95
Last 14 days:   0.85
Last 30 days:   0.7
Last 90 days:   0.4
Older:          0.1
```

**Source Weighting:**
```
Whatnot live auction:     1.1  (true competitive bidding)
eBay auction completed:   1.0  (reference point)
eBay BIN sold:           0.95  (seller priced, buyer agreed)
eBay Best Offer:         0.85  (negotiated = below market)
PriceCharting:           0.8   (aggregated, may be stale)
```

**Combined Weight:** `final_weight = recency_weight × source_weight`

**Outlier Rejection:** Remove prices >3 standard deviations from median

**Confidence Calculation:**
- Sample size: n<3 = LOW, n>10 = HIGH
- Price variance: CV > 0.5 = warn user
- Recency: all sales >90 days = lower confidence
- Grade match: exact match vs ±1 tolerance

### Phase 3.3: Visual Tuning Dashboard (Admin)

**Vision:** An admin-only interface for adjusting FMV model parameters with real-time preview of effects.

```
┌─────────────────────────────────────────────────────────┐
│ FMV Model Configuration                          [Save] │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ Recency Decay                                          │
│ Conservative ○━━━━━━━━━● Aggressive                    │
│                                                         │
│ Source Weights                                          │
│ Whatnot     [━━━━━●━━━] 1.1x                           │
│ eBay BIN    [━━━●━━━━━] 0.95x                          │
│ Best Offer  [━●━━━━━━━] 0.85x                          │
│                                                         │
│ Outlier Threshold                                       │
│ Strict ○━━━━━●━━━━○ Lenient    (2.5 std dev)          │
│                                                         │
├─────────────────────────────────────────────────────────┤
│ Preview: Amazing Spider-Man #300 CGC 9.4               │
│                                                         │
│ Current Model: $485 (HIGH confidence)                   │
│ New Model:     $512 (+5.6%)                            │
│                                                         │
│ Sample breakdown:                                       │
│  • 3 Whatnot sales (avg $520) weight: 3.3             │
│  • 8 eBay sales (avg $475) weight: 7.2                │
│  • 2 PriceCharting (avg $490) weight: 1.4             │
└─────────────────────────────────────────────────────────┘
```

### Phase 3.4: Self-Improving Model

**Phase A - Collect Metrics:**
| Metric | What it measures | How to capture |
|--------|------------------|----------------|
| Prediction accuracy | FMV vs actual sale | Backtest: hide 20% of sales, predict, compare |
| Sell-through rate | Did listings sell at our price? | Track eBay listing → sold |
| User override rate | How often users reject our price | Log when user changes price |
| Time-to-sale | Quick Sale = faster? | eBay sold date - list date |
| Confidence calibration | 80% confident = right 80% of time? | Statistical analysis |

**Phase B - AI Recommends:**
- System analyzes metrics weekly
- Generates recommendations: "Increase Whatnot weight to 1.15 based on 92% accuracy vs 87% for eBay"
- Human reviews and approves changes
- Version history tracks all model changes

**Phase C - Auto-Tune (Future):**
- AI adjusts weights within guardrails automatically
- Reports changes in weekly digest
- Human can override or roll back
- Guardrails prevent extreme swings (max ±10% change per week)

### Phase 3.5: Context-Aware Adjustments (Future Research)

**Factors to explore:**
- **Day/time:** Saturday night auctions run hotter?
- **Competition:** Whatnot 50 viewers vs 8 viewers
- **Bid count:** 15 bids = high demand vs 1 bid
- **Seller reputation:** Premium seller vs liquidator
- **Market events:** Movie announcements, creator deaths, etc.

**Approach:** Start simple, collect data, let patterns emerge. Don't over-engineer before we have evidence.

---

## Phase 4: Community & Trust Features

### Phase 4.1 - Collection Features (Current)
- [x] Save items to personal collection
- [x] Basic collection view
- [ ] Collection portfolio value (sum of FMV)
- [ ] "My collection changed by +$X this month"

### Phase 4.2 - User Feedback Loop
- [ ] "Was this valuation accurate?" (thumbs up/down)
- [ ] Submit corrections ("I sold for $X")
- [ ] Corrections improve model (with fraud detection)
- [ ] User reputation scores

### Phase 4.3 - Community Price Corrections
- [ ] Suggest corrections with evidence
- [ ] Community voting on corrections
- [ ] Weighted by user reputation
- [ ] Auto-flag suspicious patterns

### Phase 4.4 - Gamification
- [ ] Badges for contributions
- [ ] Leaderboard of top contributors
- [ ] Early access to new features
- [ ] "Trusted Valuator" status

---

## Phase 5: Model Management

### Phase 5.1 - Admin Dashboard
- [ ] View current model parameters
- [ ] Adjust weights via sliders (see 3.3)
- [ ] Preview impact before saving
- [ ] A/B testing support
- [ ] Rollback capability

### Phase 5.2 - Audit Trail
- [ ] Log all model changes
- [ ] Who changed what, when
- [ ] Before/after comparisons
- [ ] Compliance-ready history

### Phase 5.3 - Automated Recommendations
- [ ] Weekly analysis of prediction accuracy
- [ ] Flag underperforming segments
- [ ] Suggest parameter adjustments
- [ ] Admin approval workflow
- [ ] Version history for model changes

### Phase 5.5: Price Database Integration
License professional price data for faster, more accurate valuations.

**Business Case:**
- Cost: ~$200/mo for API access
- Break-even: ~20 paying users at $10/mo
- Competitive necessity: Ludex and competitors use similar data

**Candidates to evaluate:**
| Provider | Data | Pros | Cons |
|----------|------|------|------|
| GoCollect | 500k+ comics, CGC census, trends | Most comprehensive | Higher cost |
| GPA (GPAnalysis) | CGC sales focus | Accurate for slabs | Less raw data |
| PriceCharting | Comics + games + cards | Multi-vertical | Less depth |

**Implementation:**
- [ ] Evaluate GoCollect vs GPA vs PriceCharting APIs
- [ ] License price database (~$200/mo when revenue supports)
- [ ] Build import pipeline (weekly sync)
- [ ] Use DB as primary source, fall back to real-time search for misses
- [ ] Add price history charts to UI
- [ ] Add "trending up/down" indicators
- [ ] CGC census integration (population reports - how rare is a 9.8?)

**Mike's Note:** Background in hotel revenue management / dynamic pricing applies here. Same problem domain - predicting optimal price based on features. Comics features: title, issue, grade, key status, market heat.

---

## Phase 6: Price Prediction & Trends
Forecast future values based on market momentum.

#### 6.1 - Trend Analysis
- [ ] Track price history over time per comic
- [ ] Calculate momentum (rate of change)
- [ ] Identify acceleration (is growth speeding up or slowing?)

#### 6.2 - Prediction Model
| Trend Signal | Prediction |
|--------------|------------|
| Strong upward + accelerating | "Expected +X% in 30 days" |
| Upward but slowing | "Growth may stabilize" |
| Flat | "Stable pricing expected" |
| Downward | "Expected -X% in 30 days" |

#### 6.3 - Prediction Confidence
- More historical data = higher confidence
- Recent volatility = lower confidence
- External factors (movie announcements, etc.) = flag as "catalyst detected"

#### 6.4 - Dashboards
- [ ] Individual comic price chart with forecast line
- [ ] **Top 10 Hottest** - Fastest predicted increases
- [ ] **Top 10 Cooling** - Biggest predicted decreases
- [ ] **Trending Now** - Comics with sudden momentum shifts

#### 6.5 - Alerts (Future)
- [ ] "Absolute Batman #1 jumped 15% this week"
- [ ] User watchlists with price alerts
- [ ] Weekly "market movers" email digest

---

## Phase 7: Photo Upload (Now part of QuickList)
~~AI-powered comic identification.~~ **Moved to Phase 2.85**

---

## Phase 8: Advanced Features
- [ ] Price history charts
- [ ] Collection portfolio tracking
- [ ] Price alerts ("notify me if X drops below $50")
- [ ] Export to CSV/PDF
- [ ] Public API for third-party integrations
- [ ] Win/loss tracking (did you win the auction?)
- [ ] Profit calculator (purchase price vs current FMV)

---

## Phase 9: Multi-Collectible Expansion
Extend platform to additional verticals.

| Phase | Vertical | Complexity | Key Features |
|-------|----------|------------|--------------|
| 9.1 | Sports Cards | Medium | PSA/BGS grades, rookie flags, auto/jersey |
| 9.2 | Pokémon/TCGs | Medium | Set info, rarity, 1st edition, holo types |
| 9.3 | Coins | High | Mint marks, die varieties, strike quality |
| 9.4 | Vinyl Records | Medium | Pressing info, matrix numbers, Discogs data |
| 9.5 | Sneakers | Medium | Colorway, collabs, deadstock status |
| 9.6 | Watches | High | Complex market, authentication needs |

#### Shared Core Engine (reusable across verticals)
- [ ] eBay search abstraction
- [ ] Recency weighting (universal)
- [ ] Confidence scoring (universal)
- [ ] Price prediction (universal)
- [ ] User adjustments (universal)
- [ ] Photo upload/recognition (per-vertical training)

---

## Budget Phases 💰

| Phase | Monthly Cost | Stack |
|-------|--------------|-------|
| MVP (Current) | ~$7 | Render Starter + PostgreSQL |
| Beta | ~$15-25 | + Anthropic Tier 2 |
| Production | ~$50-100 | When revenue justifies |

### Anthropic API Costs
- **Current Tier:** Tier 2 (450k tokens/min, $60 credits deposited)
- **Capacity:** 20-50 comics/minute comfortable, 100+ may need pacing
- **Cost per valuation:** ~$0.01-0.02 (with caching)
- **Cost per QuickList (extract+valuate+describe):** ~$0.02-0.03

### Premium Tier Opportunity 💎 (Discovered Session 7)
**Opus model provides significantly better signature detection.**

| Feature | Sonnet (Standard) | Opus (Premium) |
|---------|-------------------|----------------|
| Cost per extraction | ~$0.01 | ~$0.05 |
| Basic extraction | ✅ Great | ✅ Great |
| Obvious signatures | ✅ Works | ✅ Works |
| Subtle signatures (gold/metallic on dark) | ❌ Misses | ✅ Detects |

**Proven:** Moon Knight #1 signed by Danny Miki (gold marker)
- Sonnet: `signature_detected: false`
- Opus: `signature_detected: true`, listed all creators with confidence %
- Note: Opus detects THAT a signature exists, but can't reliably identify WHO signed

**Future enhancement:** Reference Signature Database
- Collect verified creator signatures (eBay ~$1 each)
- Store as reference images
- AI compares uploaded signature to references for identification
- Could significantly improve "who signed" accuracy

**Implementation:** Code is ready in app.js - just uncomment the Opus line.

**Pricing idea:** "Super User" tier at ~$10/month could include:
- Opus-powered extraction
- Priority processing
- Extended collection storage
- Advanced analytics

---

## Success Metrics

### FMV Engine Metrics (NEW)
- **Prediction accuracy** - Backtest: hide 20% of sales, predict, measure error
- **Confidence calibration** - When we say 80% confident, are we right 80% of time?
- **Source contribution** - Which sources improve accuracy most?
- **Recency impact** - How much does freshness matter by category?

### Accuracy Metrics
- **User adjustments trending toward zero** - Model matches expectations
- **Extraction accuracy** - % of issue numbers read correctly
- **Signature detection accuracy** - % of signatures detected (needs quality images)

### Coverage Metrics
- **DB hit rate** - % of lookups found in database vs requiring AI search
- **Collectible verticals** - Number of active verticals (target: 5+ by 2027)
- **Data sources integrated** - eBay, Whatnot, PriceCharting, etc.

### Engagement Metrics
- **Return users** - Users coming back to value more items
- **Collections tracked** - Total items in user portfolios
- **Feedback submissions** - Community corrections submitted
- **eBay listings created** - Conversion from valuation to listing
- **QuickList completions** - Users completing full photo-to-listing flow

### Business Metrics
- **Cost per valuation** - Target: <$0.01 average (with DB caching)
- **API revenue** - Third-party integrations (future)
- **Sell-through rate** - % of CC-priced listings that sell

---

## Relevantsee Heritage 🧬

The FMV Engine architecture draws from **Relevantsee** - an autonomous marketing intelligence platform concept developed by Mike over 30+ years in MarTech.

**Core Principles (applicable to CollectionCalc):**
1. **Multi-source data fusion** - No single source has the complete picture
2. **Intelligent weighting** - Not all data is equally valuable
3. **Self-improving models** - Systems should learn from outcomes
4. **Human-in-the-loop** - AI recommends, humans approve (initially)
5. **Transparent reasoning** - Users should understand why they got a price
6. **Guardrailed autonomy** - Eventually auto-tune within safe bounds

**CollectionCalc as Proof of Concept:**
If these principles work for comic pricing, they work for any domain where:
- Multiple data sources exist
- Prices change over time
- Confidence varies
- Users need actionable recommendations

This is the same problem as ad spend optimization, hotel revenue management, and dynamic pricing - just applied to collectibles.

---

## Version History

| Date | Version | Changes |
|------|---------|---------|
| Jan 24, 2026 | 3.0.0 | 🧠 **FMV Engine architecture!** Multi-source data integration, Whatnot Valuator integration, visual tuning dashboard vision, self-improving model phases, Relevantsee heritage |
| Jan 22, 2026 | 2.89.1 | 💎 **Opus Premium tier tested!** Signature detection works with Opus, code ready for Premium pricing |
| Jan 22, 2026 | 2.89.0 | 📁 **Frontend 3-file split!** index.html/styles.css/app.js, signature confidence UI, improved issue # detection |
| Jan 21, 2026 | 2.88.0 | 🔐 **User auth & collections!** Email/password signup, JWT tokens, save comics |
| Jan 21, 2026 | 2.86.3 | 🐛 **Cache key fix!** Grade now included in cache key |
| Jan 21, 2026 | 2.86.2 | 📋 **Visual condition assessment!** Defect detection, signature detection |
| Jan 21, 2026 | 2.86.1 | GDPR endpoint, smart image compression, thumbnails, mobile fixes |
| Jan 20, 2026 | 2.85.1 | Sort options, Vision Guide v1 |
| Jan 20, 2026 | 2.85.0 | 🚀 **QuickList batch processing!** |
| Jan 19, 2026 | 2.8.0 | 🎉 **First live eBay listing!** |
| Jan 18, 2026 | 2.7.5 | AI descriptions, listing preview modal |
| Jan 17, 2026 | 2.7.0 | eBay OAuth (sandbox), listing buttons |
| Jan 15, 2026 | 2.5.0 | Three-tier pricing, PostgreSQL migration |

---

## Related Documents

- [Claude Notes](CLAUDE_NOTES.md) - Session context and working notes
- [Architecture](ARCHITECTURE.md) - System diagrams
- [Brand Guidelines](BRAND_GUIDELINES.md) - Colors, typography, UI components
- [Competitive Analysis](COMPETITIVE_ANALYSIS.md) - Market research & academic findings
- [Database](DATABASE.md) - Schema documentation
- [Budget](BUDGET.md) - Hosting strategy

---

*Last updated: January 24, 2026 (FMV Engine architecture, Whatnot integration, Relevantsee heritage)*
